/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facility;

import java.sql.Connection;
import java.sql.Connection;
import java.sql.ResultSet;
//import java.sql.Statement;
//import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql. *;

/**
 *
 * @author pc
 */
public class db {
    public static Connection mycon(){
        try{
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection("jdbc:MySQL://localhost:3306/facility_management_hospital","root","");
            
            return c;
        }catch(Exception e){
            System.out.println(e);
            
        }
        return null;
    }
}
